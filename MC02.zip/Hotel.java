
import java.util.ArrayList;
/**
 * Class file for Hotel
 * @author Sean Regindin
 */
public class Hotel {
    /**
     * String
     */
    private String name;
    /**
     * int
     */
    private int numRooms;
    /**
     * ArrayList<Room>
     */
    private ArrayList<Room> rooms;
    /**
     * ArrayList<Reservation>
     */
    private ArrayList<Reservation> reservations = new ArrayList<Reservation>();
    
    /**
     * Constructor of a Hotel object
     * @param name name of the hotel
     * @param numRooms number of rooms in the hotel
     */
    public Hotel(String name, int numRooms){
        this.name = name;
        this.numRooms = numRooms;
        rooms = new ArrayList<>(numRooms);
        for(int i = 0; i < numRooms; i++){
            Room temp = new Room(String.valueOf(300 + i));
            rooms.add(temp);
        }
    }

    /**
     * Method that sets the name of the Hotel
     * @param name the expected name change
     */
    public void setName(String name){
        this.name = name;
    }

    /**
     * Method that sets the number of rooms
     * @param numRooms the expected number of rooms
     */
    public void setNumRooms(int numRooms){
        this.numRooms = numRooms;
    }

    /**
     * Method that returns the name of the hotel
     * @return name
     */
    public String getName(){
        return name;
    }

    /**
     * Method that returns the number of rooms
     * @return numRooms
     */
    public int getNumRooms(){
        return numRooms;
    }
    
    /**
     * Method that shows the estimated earnings of the hotel
     * @return total reservation prices
     */
    public double getEstimatedEarnings(){
        double total = 0;
        for(int i = 0; i < reservations.size(); i++){
            total += reservations.get(i).getTotalPrice();
        }
        return total;
    }

    /**
     * Method that gets the number of reservations in the hotel
     * @return number of reservations
     */
    public int getReservationNum(){
        return reservations.size();
    }

    /**
     * Method that adds a room in a certain index
     * @param index the expected index where the room will be added
     * @param room the Room object that will be added
     */
    public void addRoom(int index, Room room){
        rooms.add(index, room);
        for(int i = 0; i < numRooms; i++){
            rooms.get(i).setName(String.valueOf(300 + i));
        }
    }

    /**
     * Method that adds a room at the end
     * @param room Room object that will be added
     */
    public void addRoom(Room room){
        rooms.add(room);
        for(int i = 0; i < numRooms; i++){
            rooms.get(i).setName(String.valueOf(300 + i));
        }
        numRooms++;
    }

    /**
     * Method that removes a room
     * @param index the index of the room that will be removed
     */
    public void removeRoom(int index){
        rooms.remove(index);
        numRooms--;
        for(int i = 0; i < numRooms; i++){
            rooms.get(i).setName(String.valueOf(300 + i));
        }
    }

    /**
     * Method that returns a Reservation object
     * @param index the index of the Reservation
     * @return the expected Reservation at the index
     */
    public Reservation getReservation(int index){
        return reservations.get(index - 1);
    }

    /**
     * Method that returns a Room object
     * @param index the index of the Room
     * @return the expected Room at the index
     */
    public Room getRoom(int index){
        return rooms.get(index - 1);
    }

    /**
     * Method that gets the ArrayList of reservations
     * @return reservations
     */
    public ArrayList<Reservation> getReservations(){
        return reservations;
    }

    /**
     * Method that gets the ArrayList of rooms
     * @return rooms
     */
    public ArrayList<Room> getRooms(){
        return rooms;
    }

    /**
     * Method that shows if the Hotel has exsisting reservation
     * @return true if it has reservation; else false
     */
    public boolean hasReservation(){
        for(int i = 0; i < rooms.size(); i++){
            if(rooms.get(i).isReserved() == true)
                return true;
        }
        return false;
    }

    /**
     * Method that adds a reservation in the end
     * @param reservation the Reservation object that will be added
     */
    public void addReservation(Reservation reservation){
        reservations.add(reservation);
    }

    /**
     * Method that removes a reservation
     * @param index the index of the reservation that will be removed
     */
    public void removeReservation(int index){
        Room temp = reservations.get(index - 1).getRoom();
        for(int i = 0; i < numRooms; i++){
            if(temp.getName().equals(rooms.get(i).getName())){
                rooms.get(i).setDatesReservation(reservations.get(index - 1).getCheckIn(), reservations.get(index - 1).getCheckOut(), false);
            }
        }
        reservations.remove(index - 1);
    }

    /**
     * Method that get the total earnings
     * @return earnings of the hotel
     */
    public double getEarnings(){
        double earnings = 0;
        for(int i = 0; i < reservations.size(); i++){
            earnings += reservations.get(i).getTotalPrice();
        }
        return earnings;
    }

    /**
     * Method that sets the price of the room
     * @param price the change of the price
     */
    public void setPrices(double price){
        for(int i = 0; i < numRooms; i++){
            rooms.get(i).setPrice(price);
        }
    }

    /**
     * Method that sets the rate of a certain day
     * @param day the day that the rate will change
     * @param rate the rate that changes the price rate
     */
    public void setRate(int day, double rate){
        for(int i = 0; i < numRooms; i++){
            rooms.get(i).getDate(day).setPriceRate(rate);
        }
    }

    /**
     * Method that shows the details of the room
     * @param index the index of the room
     * @return details about the room
     */
    public String showRoomDetails(int index){
        String text = "";
        double money;
        text = text + "Room name: " + rooms.get(index).getName() + "\n";
        text = text + "Room type: " + rooms.get(index).getType() + "\n";
        text = text + "Room price: " + rooms.get(index).getPrice() + "\n";
        if(rooms.get(index).isReserved()){
            text = text + "\n-----------------------------------------------";
            text = text + "\nReservations:\n";
            for(int i = 0; i < reservations.size(); i++){
                if(reservations.get(i).getRoom().getName().equals(rooms.get(index).getName())){
                    money = reservations.get(i).getTotalPrice();
                    money = Math.round(money * 100);
                    money = money / 100;
                    text = text + "\nGuest: " + reservations.get(i).getGuestName() + "\n";
                    text = text + "Check In: " + reservations.get(i).getCheckIn() + "\n";
                    text = text + "CheckOut: " + reservations.get(i).getCheckOut() + "\n";
                    text = text + "Price: " + money + "\n";
                    text = text + "-----------------------------------------------";       
                }
            }
        }

        return text;
    }

    /**
     * Method that sets the Room names
     */
    public void setRoomNames(){
        for(int i = 0; i < numRooms; i++){
            rooms.get(i).setName(String.valueOf(300 + i));
        }
    }
}
