import java.util.ArrayList;
/**
 * <p>Class file for the Hotel Reservation System</p>
 * @author Sean Regindin
 */
public class HRS {
    /**
     * ArrayList<Hotel>
     */
    private ArrayList<Hotel> hotels = new ArrayList<Hotel>();
    /**
     * int
     */
    private int numHotels;

    /**
     * Constructor for the HRS
     */
    public HRS(){
        this.numHotels = 0;
    }

    /**
     * Method returns integer
     * @return number of the Hotels created
     */
    public int getNumHotels(){
        return numHotels;
    }

    /**
     * Method is void
     * @param hotel Adds a hotel in the ArrayList of hotels
     */
    public void addHotel(Hotel hotel){
            hotels.add(hotel);
            numHotels++;
    }

    /**
     * Method is void
     * @param index the index of the hotel that will be removed
     */
    public void removeHotel(int index){
        hotels.remove(index - 1);
        numHotels--;
    }

    /**
     * Method returns a Hotel object
     * @param index index of the hotel that needs to be get
     * @return  the hotel of the given index
     */
    public Hotel getHotel(int index){
        return hotels.get(index - 1);
    }

    /**
     * Method that shows if there are created Hotels
     * @return true if the numHotels = 0; else false
     */
    public boolean noHotel(){
        return numHotels == 0;
    }

    /**
     * Method that shows if a name is unique in the ArrayList of hotels
     * @param name the name that will be compared
     * @return true if it is unique; else false
     */
    public boolean isUnique(String name){
        if(hotels.isEmpty()){
            return true;
        }else{
            for(int i = 0; i < hotels.size(); i++){
                if(name.equals(hotels.get(i).getName()))
                    return false;
            }
        }
        return true;
    }

    /**
     * Method that shows if all hotels have reservation
     * @return true if all have reservation; else false
     */
    public boolean AllhaveReservation(){
        int count = 0;
        for(int i = 0; i < hotels.size(); i++){
            if(hotels.get(i).hasReservation() == true)
                count++;
        }
        if(count == hotels.size())
            return true;
        
        return false;
    }

    /**
     * Method that shows the details of the hotels
     * @return details of the hotels
     */
    public String showHotels(){
        String texts = "";
        String yes;
        String money;
        for(int i = 0; i < hotels.size(); i++){
            texts = texts + (i + 1) + " of " + hotels.size() + " Hotel" + "\n"; 
            texts = texts + "Hotel name: " + hotels.get(i).getName() + "\n";
            texts = texts + "Number of rooms: " + hotels.get(i).getNumRooms() + "\n";
            if(hotels.get(i).hasReservation()){
                yes = " Yes ";
            }else{
                yes = " No ";
            }
            texts = texts + "Has Reservations: " + yes + "\n";
            if(hotels.get(i).hasReservation()){
                money = String.format("%.2f", hotels.get(i).getEstimatedEarnings());
                texts = texts + "Number of Reservations: " + hotels.get(i).getReservationNum() + "\n";
                texts = texts + "Estimated Earnings: " + money + "\n";
            }
            texts = texts + "\n-----------------------------------------------------------------------------------------------------" + "\n";
        }
        return texts;
    }
}
