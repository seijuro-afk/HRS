/**
 * <p>Class file for DeluxeRoom</p>
 * @author Sean Regindin
 */
public class DeluxeRoom extends Room{
    /**
     * float
     */
    float rate = 0.2f;
    /**
     * Constructor of the DeluxeRoom
     * @param name name of the DeluxeRoom
     * @param price price of the DeluxeRoom
     * @param date date of the DeluxeRoom
     */
    public DeluxeRoom(String name, double price, Date[] date){
        super(name, price, date);
        super.setType("Deluxe");
    }

    /**
     * Method that returns the price of the DeluxeRoom
     * @return price of the DeluxeRoom
     */
    @Override
    public double getPrice(){
        double money = super.getPrice() + (super.getPrice() * rate);
        return Math.round(money * 100) / 100;    
    }
}
