import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
/**
 * <p>Class file for SimController</p>
 * @author Sean Regindin
 */
public class SimController implements  ActionListener, DocumentListener {
    /**
     * HRS
     */
    private HRS hrs;
    /**
     * UI_Sim
     */
    private UI_Sim sim;
    /**
     * HRS_UI
     */
    private HRS_UI gui;


    /**
     * Constructor for SimController
     * @param hrs HRS (back-end)
     * @param sim UI_Sim (front-end)
     * @param gui HRS_UI (front-end)
     */
    public SimController(HRS hrs, UI_Sim sim, HRS_UI gui){
        this.hrs = hrs;
        this.sim = sim;
        this.gui = gui;
        sim.setActionListener(this);
    }

    /**
     * Method that updates the view of the gui
     */
    public void updateView(){
        gui.setViewButtonEnable(true);
        gui.setSimButtonEnable(true);
        gui.setCreateButtonEnable(true);
        if(hrs.AllhaveReservation()){
            gui.setChangeEnable(false);
            gui.setRemoveEnable(false);
            gui.setRateEnable(false);
        }
        else{
            gui.setChangeEnable(true);
            gui.setRemoveEnable(true);
            gui.setRateEnable(true);
        }
    }

     /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e ActionEvent
     */
    @Override
    public void actionPerformed(ActionEvent e){
        boolean success = false;
        if(e.getActionCommand().equals("Confirm")){
            if(sim.getHotel() >= 1 && sim.getHotel() <= hrs.getNumHotels()){
                if(sim.getRoom() >= 1 && sim.getRoom() <= hrs.getHotel(sim.getHotel()).getNumRooms()){
                    if(sim.getCheckIn() >= 1 && sim.getCheckIn() <= 31 && sim.getCheckOut() >= 1 && sim.getCheckOut() <= 31 && sim.getCheckIn() <= sim.getCheckOut()){
                        if(hrs.getHotel(sim.getHotel()).getRoom(sim.getRoom()).isReserved(sim.getCheckIn(), sim.getCheckOut()) == false){
                            if(sim.getCode().equals("") || sim.getCode().equals("I_WORK_HERE") || sim.getCode().equals("STAY4_GET1") || sim.getCode().equals("PAYDAY")){
                                if(sim.getCode().equals("")){
                                    success = true;
                                    hrs.getHotel(sim.getHotel()).addReservation(new Reservation(sim.getGuest(), hrs.getHotel(sim.getHotel()).getRoom(sim.getRoom()), sim.getCheckIn(), sim.getCheckOut()));
                                }
                                if(sim.getCode().equals("I_WORK_HERE")){
                                    success = true;
                                    hrs.getHotel(sim.getHotel()).addReservation(new Reservation(sim.getGuest(), hrs.getHotel(sim.getHotel()).getRoom(sim.getRoom()), sim.getCheckIn(), sim.getCheckOut(), sim.getCode()));
                                }
                                if(sim.getCode().equals("STAY4_GET1")){
                                    if(sim.getCheckOut() - sim.getCheckIn() >= 4){
                                        success = true;
                                        hrs.getHotel(sim.getHotel()).addReservation(new Reservation(sim.getGuest(), hrs.getHotel(sim.getHotel()).getRoom(sim.getRoom()), sim.getCheckIn(), sim.getCheckOut(), sim.getCode()));
                                    }
                                    else{
                                        sim.setTextError("Days in hotel does not exceed 5 days");
                                    }
                                }
                                if(sim.getCode().equals("PAYDAY")){
                                    if((sim.getCheckIn() <= 15 && sim.getCheckOut() > 15) || (sim.getCheckIn() <= 30 && sim.getCheckOut() > 30)){
                                        success = true;
                                        hrs.getHotel(sim.getHotel()).addReservation(new Reservation(sim.getGuest(), hrs.getHotel(sim.getHotel()).getRoom(sim.getRoom()), sim.getCheckIn(), sim.getCheckOut(), sim.getCode()));
                                    }
                                    else{
                                        sim.setTextError("Invalid dates");
                                    }
                                }
                                if(success == true){
                                    hrs.getHotel(sim.getHotel()).getRoom(sim.getRoom()).setDatesReservation(sim.getCheckIn(), sim.getCheckOut(), true);
                                    updateView();
                                    gui.setTxtHotels(hrs.showHotels());
                                    sim.Exit();
                                }
                            }
                            else{
                                sim.setTextError("Code does not exist");
                            }
                            
                           
                        }else{
                            sim.setTextError("Error reservation exist in dates");
                        }        
                    }
                    else{
                        sim.setTextError("Error check in/out invalid");
                    }
                }
                else{
                    sim.setTextError("Error room number is invalid");
                }
            }
            else{
                System.out.println("Error");
                sim.setTextError("Error hotel number is invalid");
            }
        }
    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
    @Override
    public void insertUpdate(DocumentEvent e){

    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
    @Override
    public void removeUpdate(DocumentEvent e){

    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
    @Override
    public void changedUpdate(DocumentEvent e){
        
    }
}
