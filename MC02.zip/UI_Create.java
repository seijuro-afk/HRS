
import java.awt.Color;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.event.DocumentListener;
/**
 * <p>Class file for UI_Create</p>
 * @author Sean Regindin
 */
public class UI_Create extends JFrame{
    /**
     * JLabel
     */ 
    private JLabel lblName;
    /**
     * JLabel
     */ 
    private JLabel lblNumber;
    /**
     * JLabel
     */ 
    private JLabel txtError;
    /**
     * JButton
     */ 
    private JButton conButton;
    /**
     * JTextField
     */ 
    private JTextField txtName;
    /**
     * JTextField
     */
    private JTextField txtRoom;
    /**
     * Constructor for UI_Create JFrame
     */
    public UI_Create(){
        super("Create Hotel");
        setSize(300, 200);
        setLayout(null);
        init();

        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(0);
    }

    /**
     * Method that initializes the JFrame
     */
    private void init(){
        lblName = new JLabel(" Name:");
        lblName.setBounds(35, 20, 80, 25);
        this.add(lblName);

        txtName = new JTextField("Enter name here");
        txtName.setBounds(90, 20, 165, 25);
        this.add(txtName);

        lblNumber = new JLabel("# of Rooms:");
        lblNumber.setBounds(10, 50, 100, 35);
        this.add(lblNumber);

        txtRoom = new JTextField("1");
        txtRoom.setBounds(90, 55, 165, 25);
        this.add(txtRoom);



        conButton = new JButton("Confirm");
        conButton.setBounds(90, 90, 165, 25);
        this.add(conButton);

        txtError = new JLabel("");
        txtError.setForeground(Color.red);
        txtError.setBounds(90, 120, 165, 25);
        this.add(txtError);

    }

    /**
     * Method that disposes the JFrame
     */
    public void Exit(){
        this.dispose();
    }
    
    /**
     * Method that returns the String value of txtName
     * @return String(txtName)
     */
    public String getName(){
        return txtName.getText();
    }

    /**
     * Method that returns the integer value of txtRoom
     * @return int(txtRoom)
     */
    public int getNumRooms(){
        return Integer.parseInt(txtRoom.getText());
    }

    /**
     * Method that set the text of txtError
     * @param text the String that will be set onto txtError
     */
    public void setTextError(String text){
        txtError.setText(text);
    }

    /**
     * Method that sets the ActionListener for conButton
     * @param listener listener of the button
     */
    public void setActionListener(ActionListener listener) {
        conButton.addActionListener(listener);
    }

    /**
     * Method that sets the DocumentListener for txtName and txtRoom
     * @param listener listener of the text field
     */
    public void setDocumentListener(DocumentListener listener) {
        txtName.getDocument().addDocumentListener(listener);
        txtRoom.getDocument().addDocumentListener(listener);
    }


}
