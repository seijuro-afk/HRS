
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.event.DocumentListener;
/**
 * <p>Class file for UI_Remove</p>
 * @author Sean Regindin
 */
public class UI_Remove extends JFrame{
    /**
     * JLabel
     */
    private JLabel selRoom;
    /**
     * JLabel
     */
    private JLabel txtError;
    /**
     * JTextField
     */
    private JTextField numHot;
    /**
     * JButton
     */
    private JButton okButton;


    /**
     * Constructor for UI_Remove JFrame
     */
    public UI_Remove(){
        super("Remove Hotel");
        setSize(250, 150);
        setLayout(null);

        init();

        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(0);
    }

    /**
     * Method that initializes the JFrame
     */
    private void init(){
        selRoom = new JLabel("Hotel Number: ");
        selRoom.setBounds(35, 20, 100, 25);
        this.add(selRoom);

        numHot = new JTextField("1");
        numHot.setBounds(130, 20, 50, 25);
        this.add(numHot);

        okButton = new JButton("Ok");
        okButton.setBounds(130, 60, 50, 35);
        this.add(okButton);

        txtError = new JLabel("");
        txtError.setBounds(65, 65, 50, 25);
        this.add(txtError);
    }

    /**
     * Method that returns the integer value of numHot
     * @return int(numHot)
     */
    public int getHotelNumber(){
        return Integer.parseInt(numHot.getText());
    }

    /**
     * Method that sets the text of txtError
     * @param text the text that will be set onto txtError
     */
    public void setTextError(String text){
        txtError.setText(text);
    }

    /**
     * Method that sets the ActionListener on the okButton
     * @param listener listener of the button
     */
    public void setActionListener(ActionListener listener) {
        okButton.addActionListener(listener);
    }

    /**
     * Method that sets the DocumentListener on the numHot
     * @param listener listener of the text field
     */
    public void setDocumentListener(DocumentListener listener) {
        numHot.getDocument().addDocumentListener(listener);
    }

    /**
     * Method that disposes the JFrame
     */
    public void Exit(){
        this.dispose();
    }
}
