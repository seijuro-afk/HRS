import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 * Class file for CreateController
 * @author Sean Regindin
 */
public class CreateController implements ActionListener, DocumentListener {
    /**
     * HRS
     */
    private HRS hrs;
    /**
     * UI_Create
     */
    private UI_Create create;
    /**
     * HRS_UI
     */
    private HRS_UI gui;

    /**
     * Constructor for CreateController Object
     * @param hrs HRS (back-end)
     * @param create UI_Create (front-end)
     * @param gui HRS_UI (front-end)
     */
    public CreateController(HRS hrs, UI_Create create, HRS_UI gui){
        this.hrs = hrs;
        this.create = create;
        this.gui = gui;
        create.setActionListener(this);
    }

    /**
     * Method that updates the view of the gui
     */
    public void updateView(){
        gui.setHotelNumber(hrs.getNumHotels());
        gui.setTxtHotels(hrs.showHotels());
        gui.setCreateButtonEnable(true);
        if(hrs.noHotel()){
            gui.setViewButtonEnable(false);
            gui.setSimButtonEnable(false);
            gui.setRemoveEnable(false);
            gui.setChangeEnable(false);
            gui.setRateEnable(false);
        }else{
            gui.setViewButtonEnable(true);
            gui.setSimButtonEnable(true);
            gui.setRemoveEnable(true);
            gui.setChangeEnable(true);
            gui.setRateEnable(true);
        }
    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e ActionEvent
     */
    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getActionCommand().equals("Confirm")){
            if(hrs.isUnique(create.getName()) == true && create.getNumRooms() >= 1 && create.getNumRooms() <= 50){
                hrs.addHotel(new Hotel(create.getName(), create.getNumRooms()));
                updateView();
                create.Exit();
            }
            else{
                if(!(create.getNumRooms() >= 1) || !(create.getNumRooms() <= 50))
                    create.setTextError("Error! # of rooms is invalid.");
                if(!(hrs.isUnique(create.getName()))){
                    create.setTextError("Error! Name is not unique.");
                }
            }


        }
    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
    @Override
    public void insertUpdate(DocumentEvent e){

    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
    @Override
    public void removeUpdate(DocumentEvent e){

    }

     /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
    @Override
    public void changedUpdate(DocumentEvent e){
        
    }
}
