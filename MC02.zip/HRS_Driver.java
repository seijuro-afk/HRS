/**
 * <p>Class File for the Driver of the whole application</p>
 *  @author Sean Regindin
 */
 public class HRS_Driver {
    
    /**
     * Constructor for HRS_Driver
     */
    public HRS_Driver(){

    }
    /**
     * The main function
     * @param args an array of command-line arguments for the application
     */
    public static void main(String[] args){
        HRS_UI gui = new HRS_UI();
        HRS hrs = new HRS();
        Controller controller = new Controller(gui, hrs);
    }
}
