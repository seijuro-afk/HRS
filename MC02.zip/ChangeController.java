import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 * Class file for ChangeController
 * @author Sean Regindin
 */
public class ChangeController implements ActionListener, DocumentListener{
    /**
     * HRS
     */
    private HRS hrs;
    /**
     * HRS_UI
     */
    private HRS_UI gui;
    /**
     * UI_Change
     */
    private UI_Change change;
    /**
     * Constructor for ChangeController
     * @param hrs HRS object (back-end)
     * @param gui HRS_UI (front-end)
     * @param change UI_Change (front-end)
     */
    public ChangeController(HRS hrs, HRS_UI gui, UI_Change change){
        this.hrs = hrs;
        this.gui = gui;
        this.change = change;
        change.setActionListener(this);
    }

    /**
     * Method that updates the view of the gui
     */
    public void updateView(){
        if(hrs.noHotel()){
            gui.setViewButtonEnable(false);
            gui.setSimButtonEnable(false);
            gui.setRemoveEnable(false);
            gui.setChangeEnable(false);
            gui.setRateEnable(false);
        }else{
            gui.setViewButtonEnable(true);
            gui.setSimButtonEnable(true);
            gui.setRemoveEnable(true);
            gui.setChangeEnable(true);
            gui.setRateEnable(true);
        }
        gui.setCreateButtonEnable(true);
    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e ActionEvent
     */
    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getActionCommand().equals("Ok")){
            if(change.getHotelNumber() >= 1 && change.getHotelNumber() <= hrs.getNumHotels()){
                if(change.getPriceChange() >= 100.00){
                    if(hrs.getHotel(change.getHotelNumber()).hasReservation() == false){
                        hrs.getHotel(change.getHotelNumber()).setPrices(change.getPriceChange());
                        updateView();
                        change.Exit();
                    }
                    else{
                        change.setTextError("Hotel has reservation");
                    }
                }
                else{
                    change.setTextError("Price Invalid");
                }
            }
            else{
                change.setTextError("Error");
            }
        }
    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
    @Override
    public void insertUpdate(DocumentEvent e){

    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
    @Override
    public void removeUpdate(DocumentEvent e){

    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
    @Override
    public void changedUpdate(DocumentEvent e){
        
    }
}
