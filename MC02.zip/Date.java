/**
 * <p>Class file for Date</p>
 * @author Sean Regindin
 */
public class Date {
    /**
     * boolean
     */
    boolean isBooked;
    /**
     * double
     */
    double price_rate;

    /**
     * Constructor for Date object
     */
    public Date(){
        this.isBooked = false;
        this.price_rate = 1.0;
    }

    /**
     * Constructor for Date object
     * @param price_rate the price rate of the Date
     */
    public Date(double price_rate){
        this.isBooked = false;
        this.price_rate = price_rate;
    }

    /**
     * Method that sets whether the Date is booked
     * @param isBooked true if it is booked; else false
     */
    public void setIsBooked(boolean isBooked){
        this.isBooked = isBooked;
    }

    /**
     * Method that sets the price rate of the Date
     * @param price_rate price rate change
     */
    public void setPriceRate(double price_rate){
        this.price_rate = price_rate;
    }

    /**
     * Method that returns the value of isBooked
     * @return isBooked
     */
    public boolean getIsBooked(){
        return isBooked;
    }
    
    /**
     * Method that returns the value of price_rate
     * @return price_rate
     */
    public double getPriceRate(){
        return price_rate;
    }
}
