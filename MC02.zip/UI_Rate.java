
import java.awt.Color;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.event.DocumentListener;

/**
 * <p>Class file for UI_Rate</p>
 * @author Sean Regindin
 */
public class UI_Rate extends  JFrame{
    /**
     * JLabel
     */ 
    private JLabel selHotel;
    /**
     * JLabel
     */ 
    private JLabel selRate;
    /**
     * JLabel
     */ 
    private JLabel selDay;
    /**
     * JLabel
     */ 
    private JLabel txtError;
    /**
     * JTextField
     */ 
    private JTextField numHot;
    /**
     * JTextField
     */ 
    private JTextField numRate;
    /**
     * JTextField
     */ 
    private JTextField numDay;
    /**
     * JButton
     */ 
    private JButton okButton;

    /**
     * Constructor for UI_Rate
     */
    public UI_Rate(){
        super("Change rate of a Hotel");

        setSize(350, 250);
        setLayout(null);

        init();

        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(0);
    }

    /**
     * Method that initializes the JFrame
     */
    private void init(){
        selHotel = new JLabel("Hotel Number: ");
        selHotel.setBounds(35, 20, 100, 25);
        this.add(selHotel);

        numHot = new JTextField("1");
        numHot.setBounds(130, 20, 50, 25);
        this.add(numHot);

        selDay = new JLabel("Day: ");
        selDay.setBounds(35, 60, 100, 25);
        this.add(selDay);

        numDay = new JTextField("1");
        numDay.setBounds(130, 60, 50, 25);
        this.add(numDay);

        selRate = new JLabel("Rate: ");
        selRate.setBounds(35, 100, 100, 25);
        this.add(selRate);

        numRate = new JTextField("1.0");
        numRate.setBounds(130, 100, 50, 25);
        this.add(numRate);
        
        okButton = new JButton("Ok");
        okButton.setBounds(130, 140, 50, 35);
        this.add(okButton);

        txtError = new JLabel("");
        txtError.setForeground(Color.red);
        txtError.setBounds(65, 180, 200, 25);
        this.add(txtError);
    }

    /**
     * Method that returns the integer value of numHot
     * @return int(numHot)
     */
    public int getHotelNumber(){
        return Integer.parseInt(numHot.getText());
    }

    /**
     * Method that returns the double value of numRate
     * @return double(numRate)
     */
    public double getRateChange(){
        return Double.parseDouble(numRate.getText());
    }

    /**
     * Method that returns the integer value of numDay
     * @return int(numDay)
     */
    public int getDayNumber(){
        return Integer.parseInt(numDay.getText());
    }

    /**
     * Method that sets the text of txtError
     * @param text the text that will be set onto txtError
     */
    public void setTextError(String text){
        txtError.setText(text);
    }

    /**
     * Method that sets the ActionListener for okButton
     * @param listener listener of the buttons
     */
    public void setActionListener(ActionListener listener) {
        okButton.addActionListener(listener);
    }

    /**
     * Method that sets the DocumentListener for the text fields
     * @param listener listener of the textfields
     */
    public void setDocumentListener(DocumentListener listener) {
        numHot.getDocument().addDocumentListener(listener);
        numDay.getDocument().addDocumentListener(listener);
        numRate.getDocument().addDocumentListener(listener);
    }

    /**
     * Method that disposes the JFrame
     */
    public void Exit(){
        this.dispose();
    }
}
