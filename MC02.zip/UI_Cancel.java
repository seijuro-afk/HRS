
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.event.DocumentListener;
/**
 * <p>Class file for UI_Cancel JFrame</p>
 * @author Sean Regindin
 */
public class UI_Cancel extends JFrame{
    /**
     * JLabel
     */
    private JLabel selRoom;
    /**
     * JLabel
     */
    private JLabel txtError;
    /**
     * JTextField
     */
    private JTextField numRes;
    /**
     * JButton
     */
    private JButton okButton;

    /**
     * UI_Cancel JFrame Constructor
     */
    public UI_Cancel(){
        super("Cancel Reservation");
        setSize(350, 150);
        setLayout(null);

        init();

        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    /**
     * Method that initialized the JFrame
     */
    private void init(){
        selRoom = new JLabel("Res Number: ");
        selRoom.setBounds(35, 20, 100, 25);
        this.add(selRoom);

        numRes = new JTextField("1");
        numRes.setBounds(130, 20, 50, 25);
        this.add(numRes);

        okButton = new JButton("Ok");
        okButton.setBounds(130, 60, 50, 35);
        this.add(okButton);

        txtError = new JLabel("");
        txtError.setBounds(65, 65, 50, 25);
        this.add(txtError);
    }

    /**
     * Method that returns the integer value of numRes
     * @return int(numRes)
     */
    public int getResNumber(){
        return Integer.parseInt(numRes.getText());
    }

    /**
     * Method that set the value of txtError
     * @param text the value that txtError will get
     */
    public void setTextError(String text){
        txtError.setText(text);
    }

    /**
     * Method that sets the ActionListener for okButton
     * @param listener listener of the button
     */
    public void setActionListener(ActionListener listener) {
        okButton.addActionListener(listener);
    }

    /**
     * Method that sets the DocumentListener for numRes
     * @param listener listener for the textfield
     */
    public void setDocumentListener(DocumentListener listener) {
        numRes.getDocument().addDocumentListener(listener);
    }

    /**
     * Method that disposes the Jframe
     */
    public void Exit(){
        this.dispose();
    }
}
