

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
/**
 * <p>Class file for ViewController</p>
 * @author Sean Regindin
 */
public class ViewController implements ActionListener, DocumentListener{
   /**
    * HRS
    */
    private HRS hrs;
    /**
    * UI_View
    */
    private UI_View view;
    /**
    * HRS_UI
    */
    private HRS_UI gui;
    /**
    * Hotel_View
    */
    private Hotel_View view_gui;
    /**
    * HotelViewController
    */
    private HotelViewController controller;

    /**
     * Constructor for ViewController Object
     * @param hrs HRS (back-end)
     * @param view UI_View (front-end)
     * @param gui HRS_UI (front-end)
     */
    public ViewController(HRS hrs, UI_View view, HRS_UI gui){
        this.hrs = hrs;
        this.view = view;
        this.gui = gui;
        view.setActionListener(this);
    }

    /**
     * Method that updates the view of the gui
     */
    public void updateView(){
            gui.setViewButtonEnable(false);
            gui.setSimButtonEnable(false);
            gui.setCreateButtonEnable(false);
            gui.setRemoveEnable(false);
            gui.setChangeEnable(false);
    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e ActionEvent
     */
    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getActionCommand().equals("Ok")){
            if(view.getHotelNumber() >= 1 && view.getHotelNumber() <= hrs.getNumHotels()){
                view.JButton1ActionPerformed(hrs.getHotel(view.getHotelNumber()).getName());
                this.view_gui = view.getHotel_View();
                view.Exit();
                controller = new HotelViewController(view_gui, hrs, view.getHotelNumber(), gui);
            }else{
                view.setTextError("Error");
            }
        }
    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
    @Override
    public void insertUpdate(DocumentEvent e){

    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
    @Override
    public void removeUpdate(DocumentEvent e){

    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
    @Override
    public void changedUpdate(DocumentEvent e){
        
    }


}
