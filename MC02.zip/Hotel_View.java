import java.awt.*;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 * <p>Class file for Hotel_View</p>
 * @author Sean Regindin
 */
public class Hotel_View extends JFrame{
    
    /**
     * JButton
     */
    private JButton btnPrev;
    /**
     * JButton
     */
    private JButton btnNext;
    /**
     * JButton
     */
    private JButton btnBack;
    /**
     * JButton
     */
    private JButton btnAdd;
    /**
     * JButton
     */
    private JButton btnRemove;
    /**
     * JButton
     */
    private JButton btnCancel;
    /**
     * JButton
     */
    private JButton btnReg, btnDeluxe, btnExec;
    /**
     * JTextArea
     */
    private JTextArea taDesc;
    /**
     * UI_Cancel
     */
    private UI_Cancel cancel;

    /**
     * Constructor of Hotel_View
     * @param name name of the JFrame
     */
    public Hotel_View(String name){
        super(name);
        setLayout(new BorderLayout());

        setSize(450, 500);

        init();

        setVisible(true);
        setResizable(false);

        setDefaultCloseOperation(0);
    }

    /**
     * Initializes the JFrame
     */
    private void init(){

        JPanel panelSouth = new JPanel();
        panelSouth.setLayout(new FlowLayout());
        panelSouth.setBackground(Color.cyan);

        btnReg = new JButton("Regular");
        panelSouth.add(btnReg);

        btnDeluxe = new JButton("Deluxe");
        panelSouth.add(btnDeluxe);

        btnExec = new JButton("Executive");
        panelSouth.add(btnExec);

        this.add(panelSouth, BorderLayout.SOUTH);

        JPanel panelNorth = new JPanel();
        panelNorth.setLayout(new FlowLayout());
        panelNorth.setBackground(Color.cyan);

        btnBack = new JButton("Back");
        panelNorth.add(btnBack);

        btnAdd = new JButton("Add");
        panelNorth.add(btnAdd);

        btnRemove = new JButton("Remove");
        panelNorth.add(btnRemove);

        btnCancel = new JButton("Cancel");
        panelNorth.add(btnCancel);

        this.add(panelNorth, BorderLayout.NORTH);

        JPanel panelWest = new JPanel();
        panelWest.setLayout(new GridBagLayout());
        panelWest.setBackground(Color.cyan);

        btnPrev = new JButton("<");
        panelWest.add(btnPrev);

        this.add(panelWest, BorderLayout.WEST);


        JPanel panelEast = new JPanel();
        panelEast.setLayout(new GridBagLayout());
        panelEast.setBackground(Color.cyan);

        btnNext = new JButton(">");
        panelEast.add(btnNext);

        this.add(panelEast, BorderLayout.EAST);

        JPanel panelCenter = new JPanel();
        panelCenter.setLayout(new BorderLayout());
        panelCenter.setBackground(Color.cyan);

        // Name panel inside CENTER PANEL
        JPanel panelName = new JPanel();
        panelName.setLayout(new FlowLayout());
        panelName.setBackground(Color.cyan);

        JLabel lblName = new JLabel("Room Name");
        lblName.setForeground(Color.cyan);
        panelName.add(lblName);

        taDesc = new JTextArea();
        taDesc.setEditable(false);
        taDesc.setFocusable(false);
        JScrollPane scroll = new JScrollPane(taDesc);
        panelCenter.add(scroll, BorderLayout.CENTER);

        this.add(panelCenter, BorderLayout.CENTER);
    }

    /**
     * Method that sets the ActionListener of the buttons
     * @param listener the listerner that will be added
     */
    public void setActionListener(ActionListener listener) {
        btnBack.addActionListener(listener);
        btnPrev.addActionListener(listener);
        btnNext.addActionListener(listener);
        btnReg.addActionListener(listener);
        btnDeluxe.addActionListener(listener);
        btnExec.addActionListener(listener);
        btnRemove.addActionListener(listener);
        btnAdd.addActionListener(listener);
        btnCancel.addActionListener(listener);
    }

    /**
     * Method that sets the btnPrev enabled or not
     * @param enabled enables the button if true; else false
     */
    public void setPrevEnabled(boolean enabled) {
        btnPrev.setEnabled(enabled);
    }

    /**
     * Method that sets the btnNext enabled or not
     * @param enabled enables the button if true; else false
     */
    public void setNextEnabled(boolean enabled) {
        btnNext.setEnabled(enabled);
    }

    /**
     * Method that sets the btnAdd enabled or not
     * @param enabled enables the button if true; else false
     */
    public void setAddEnabled(boolean enabled){
        btnAdd.setEnabled(enabled);
    }

    /**
     * Method that sets the btnRemove enabled or not
     * @param enabled enables the button if true; else false
     */
    public void setRemoveEnabled(boolean enabled){
        btnRemove.setEnabled(enabled);
    }

    /**
     * Method that sets the btnCancel enabled or not
     * @param enabled enables the button if true; else false
     */
    public void setCancelEnabled(boolean enabled){
        btnCancel.setEnabled(enabled);
    }

    /**
     * Method that sets the btnReg, btnDeluxe, and btnExec enabled or not
     * @param enabled enables the button if true; else false
     */
    public void setChangeRoomType(boolean enabled){
        btnReg.setEnabled(enabled);
        btnDeluxe.setEnabled(enabled);
        btnExec.setEnabled(enabled);
    }

    /**
     * Method that sets the text of taDesc
     * @param desc description 
     */
    public void setRoomDesc(String desc) {
        taDesc.setText(desc);
    }

    /**
     * Method that dispose the Jframe and returns to the Menu
     */
    public void goBackToMenu(){
        this.dispose();
    }

    /**
     * Method that activates when btnCancel is pressed
     */
    public void JButton1ActionPerformed(){
        cancel = new UI_Cancel();
    }

    /**
     * Method that returns cancel
     * @return cancel
     */
    public UI_Cancel getCancelFrame(){
        return cancel;
    }
}
