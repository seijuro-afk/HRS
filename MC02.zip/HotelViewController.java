import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 * <p>Class file for HotelViewController</p>
 * @author Sean Regindin
 */
public class HotelViewController implements ActionListener, DocumentListener{
    
    /**
     * HRS
     */
    private HRS hrs;
    /**
     * Hotel_View
     */
    private Hotel_View view;
    /**
     * int
     */
    private int indexRoom = 0;
    /**
     * int
     */
    private int hotelIndex;
    /**
     * UI_Cancel
     */
    private UI_Cancel cancel;
    /**
     * CancelController
     */
    private CancelController cancelController;
    /**
     * HRS_UI
     */
    private HRS_UI main;

    /**
     * Constructor for HotelViewController object
     * @param view Hotel_View (front-end)
     * @param hrs HRS (back-end)
     * @param hotelIndex index of the hotel
     * @param main HRS_UI (front-end)
     */
    public HotelViewController(Hotel_View view, HRS hrs, int hotelIndex, HRS_UI main){
        this.view = view;
        this.hrs = hrs;
        this.hotelIndex = hotelIndex;
        this.main = main;
        updateView();
        view.setActionListener(this);
    }

    /**
     * Updates the view and the main
     */
    public void updateView(){
        view.setRoomDesc(hrs.getHotel(hotelIndex).showRoomDetails(indexRoom));
        main.setTxtHotels(hrs.showHotels());
        if(indexRoom == 0){
            view.setPrevEnabled(false);
        }
        else{
            view.setPrevEnabled(true);
        }

        if(indexRoom == hrs.getHotel(hotelIndex).getNumRooms() - 1){
            view.setNextEnabled(false);
        }
        else{
            view.setNextEnabled(true);
        }
        if(hrs.getHotel(hotelIndex).getRoom(indexRoom + 1).isReserved() == true){
            view.setChangeRoomType(false);
        }
        else{
            view.setChangeRoomType(true);
        }
        if(hrs.getHotel(hotelIndex).getNumRooms() == 1 || hrs.getHotel(hotelIndex).getRoom(indexRoom + 1).isReserved() == true){
            view.setRemoveEnabled(false);
        }
        else{
            view.setRemoveEnabled(true);
        }
        if(hrs.getHotel(hotelIndex).getNumRooms() == 50){
            view.setAddEnabled(false);
        }
        else{
            view.setAddEnabled(true);
        }
        if(hrs.getHotel(hotelIndex).getReservationNum() == 0){
            view.setCancelEnabled(false);
        }
        else{
            view.setCancelEnabled(true);
        }
    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e ActionEvent
     */
    @Override
    public void actionPerformed(ActionEvent e){
        double normal = 0.00;
        if(hrs.getHotel(hotelIndex).getRoom(1).getType().equals("Regular")){
            normal =    hrs.getHotel(hotelIndex).getRoom(1).getPrice();
        }
        if(hrs.getHotel(hotelIndex).getRoom(1).getType().equals("Deluxe")){
            normal =    hrs.getHotel(hotelIndex).getRoom(1).getPrice() / 1.2;
        }
        if(hrs.getHotel(hotelIndex).getRoom(1).getType().equals("Executive")){
                normal =    hrs.getHotel(hotelIndex).getRoom(1).getPrice() / 1.35;
        }
        if(e.getActionCommand().equals(">")){
            indexRoom++;
            updateView();
        }
        if(e.getActionCommand().equals("<")){
            indexRoom--;
            updateView();
        }
        if(e.getActionCommand().equals("Back")){
            if(hrs.AllhaveReservation()){
                main.setChangeEnable(false);
                main.setRemoveEnable(false);
                main.setCreateButtonEnable(true);
                main.setViewButtonEnable(true);
                main.setSimButtonEnable(true);
                main.setRateEnable(false);
            }
            else{
                main.setChangeEnable(true);
                main.setRemoveEnable(true);
                main.setCreateButtonEnable(true);
                main.setViewButtonEnable(true);
                main.setSimButtonEnable(true);
                main.setRateEnable(true);
            }
            view.goBackToMenu();
        }
        if(e.getActionCommand().equals("Deluxe")){
            hrs.getHotel(hotelIndex).addRoom(indexRoom, new DeluxeRoom(hrs.getHotel(hotelIndex).getRoom(indexRoom + 1).getName(), normal, hrs.getHotel(hotelIndex).getRoom(indexRoom + 1).getDates()));
            updateView();
        }
        if(e.getActionCommand().equals("Executive")){
            hrs.getHotel(hotelIndex).addRoom(indexRoom, new ExecRoom(hrs.getHotel(hotelIndex).getRoom(indexRoom + 1).getName(), normal, hrs.getHotel(hotelIndex).getRoom(indexRoom + 1).getDates()));
            updateView();
        }
        if(e.getActionCommand().equals("Regular")){
            hrs.getHotel(hotelIndex).addRoom(indexRoom, new Room(hrs.getHotel(hotelIndex).getRoom(indexRoom + 1).getName(), normal, hrs.getHotel(hotelIndex).getRoom(indexRoom + 1).getDates()));
            updateView();
        }
        if(e.getActionCommand().equals("Remove")){
            hrs.getHotel(hotelIndex).removeRoom(indexRoom);
            if(hrs.getHotel(hotelIndex).getNumRooms() < indexRoom + 1){
                indexRoom = hrs.getHotel(hotelIndex).getNumRooms() - 1;
            }
            updateView();
        }
        if(e.getActionCommand().equals("Add")){
            hrs.getHotel(hotelIndex).addRoom(new Room(String.valueOf(300 + hrs.getHotel(hotelIndex).getNumRooms()), normal, hrs.getHotel(hotelIndex).getRoom(indexRoom + 1).getDates()));
            hrs.getHotel(hotelIndex).setRoomNames();
            updateView();
        }
        if(e.getActionCommand().equals("Cancel")){
            view.JButton1ActionPerformed();
            this.cancel = view.getCancelFrame();
            view.setCancelEnabled(false);
            view.setAddEnabled(false);
            view.setRemoveEnabled(false);
            view.setChangeRoomType(false);
            view.setNextEnabled(false);
            view.setPrevEnabled(false);
            cancelController = new CancelController(hrs, cancel, this, view, hotelIndex, indexRoom, main);
        }
    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
     @Override
    public void insertUpdate(DocumentEvent e){

    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
    @Override
    public void removeUpdate(DocumentEvent e){

    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
    @Override
    public void changedUpdate(DocumentEvent e){
        
    }
}
