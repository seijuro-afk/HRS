/**
 * <p>Class file for ExecRoom</p>
 * @author Sean Regindin
 */
public class ExecRoom extends Room{
    /**
     * float
     */
    float rate = 0.35f;
    /**
     * Constructor of the ExecRoom
     * @param name name of the ExecRoom
     * @param price price of the ExecRoom
     * @param dates dates of the ExecRoom
     */
    public ExecRoom(String name, double price, Date[] dates){
        super(name, price, dates);
        super.setType("Executive");
    }

    /**
     * Method that returns the price of the ExecRoom
     * @return the price of the ExecRoom
     */
    @Override
    public double getPrice(){
        double money = super.getPrice() + (super.getPrice() * rate);
        return Math.round(money * 100) / 100;  
    }
}
