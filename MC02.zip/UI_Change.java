
import java.awt.Color;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.event.DocumentListener;
/**
 * <p>Class file for UI_Change</p>
 * @author Sean Regindin
 */
public class UI_Change extends JFrame{
    /**
     * JLabel
     */
    private JLabel selHotel;
    /**
     * JLabel
     */ 
    private JLabel selPrice;
    /**
     * JLabel
     */ 
    private JLabel txtError;
    /**
     * JTextField
     */
    private JTextField numHot;
    /**
     * JTextField
     */
    private JTextField numPrice;
    /**
     * JButton
     */
    private JButton okButton;

    /**
     * Constructor for UI_Change JFrame
     */
    public UI_Change(){
        super("Change price of a Hotel");

        setSize(350, 250);
        setLayout(null);

        init();

        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(0);
    }

    /**
     * Method that initializes the JFrame
     */
    private void init(){
        selHotel = new JLabel("Hotel Number: ");
        selHotel.setBounds(35, 20, 100, 25);
        this.add(selHotel);

        numHot = new JTextField("1");
        numHot.setBounds(130, 20, 50, 25);
        this.add(numHot);

        selPrice = new JLabel("Price: ");
        selPrice.setBounds(35, 60, 100, 25);
        this.add(selPrice);

        numPrice = new JTextField("100.00");
        numPrice.setBounds(130, 60, 50, 25);
        this.add(numPrice);
        
        okButton = new JButton("Ok");
        okButton.setBounds(130, 100, 50, 35);
        this.add(okButton);

        txtError = new JLabel("");
        txtError.setForeground(Color.red);
        txtError.setBounds(65, 140, 200, 25);
        this.add(txtError);
    }

    /**
     * Method that returns the integer value of numHot
     * @return int(numHot)
     */
    public int getHotelNumber(){
        return Integer.parseInt(numHot.getText());
    }

    /**
     * Method that returns the double value of numPrice
     * @return double(numPrice)
     */
    public double getPriceChange(){
        return Double.parseDouble(numPrice.getText());
    }


    /**
     * Method that sets the text of txtError
     * @param text the String that will set the text of txtError
     */
    public void setTextError(String text){
        txtError.setText(text);
    }

    /**
     * Method that sets the ActionListener for okButton
     * @param listener listener of the button
     */
    public void setActionListener(ActionListener listener) {
        okButton.addActionListener(listener);
    }

    /**
     * Method that sets the DocumentListener for numHot
     * @param listener listener of the textfield
     */
    public void setDocumentListener(DocumentListener listener) {
        numHot.getDocument().addDocumentListener(listener);
    }

    /**
     * Method that disposes the JFrame
     */
    public void Exit(){
        this.dispose();
    }
}
