import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 * Class file for Controller
 * @author Sean Regindin
 */
public class Controller implements ActionListener, DocumentListener {
    /**
     * HRS_UI
     */
    private HRS_UI gui;
    /**
     * HRS
     */
    private HRS hrs;
    /**
     * UI_Create
     */
    private UI_Create create;
    /**
     * UI_View
     */
    private UI_View view;
    /**
     * UI_Sim
     */
    private UI_Sim sim;
    /**
     * UI_Remove
     */
    private UI_Remove rem;
    /**
     * UI_Change
     */
    private UI_Change change;
    /**
     * UI_Rate
     */
    private UI_Rate rate;
    /**
     * CreateController
     */
    private CreateController createController;
    /**
     * ViewController
     */
    private ViewController viewController;
    /**
     * SimController
     */
    private SimController simController;
    /**
     * RemoveController
     */
    private RemoveController remController;
    /**
     * ChangeController
     */
    private ChangeController changeController;
    /**
     * RateController
     */
    private RateController rateController;

    /**
     * Constructor of the Controller object
     * @param gui HRS_UI (front-end)
     * @param hrs HRS (back-end)
     */
    public Controller(HRS_UI gui, HRS hrs){
        this.gui = gui;
        this.hrs = hrs;
        updateView();

        gui.setActionListener(this);
    }

    /**
     * Method that updates the view of the gui
     */
    public void updateView(){
        gui.setHotelNumber(hrs.getNumHotels());

        //Initially disable manageButton, viewButton, and simButton
        gui.setViewButtonEnable(false);
        gui.setSimButtonEnable(false);
        gui.setRemoveEnable(false);
        gui.setRateEnable(false);
        if(hrs.getNumHotels() == 0){
            gui.setChangeEnable(false);
        }
        else{
            gui.setChangeEnable(true);
        }
    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e ActionEvent
     */
    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getActionCommand().equals("Create Hotel")){
            this.create = gui.getCreateHotel();
            gui.JButton1ActionPerformed();
            createController = new CreateController(hrs,  gui.getCreateHotel(), gui);
            gui.setCreateButtonEnable(false);
            gui.setViewButtonEnable(false);
            gui.setSimButtonEnable(false);
            updateView();
        }
        if(e.getActionCommand().equals("View Hotel")){
            this.view = gui.getViewHotel();
            gui.JButton2ActionPerformed();
            gui.setCreateButtonEnable(false);
            gui.setViewButtonEnable(false);
            gui.setSimButtonEnable(false);
            gui.setRemoveEnable(false);
            gui.setChangeEnable(false);
            gui.setRateEnable(false);
            viewController = new ViewController(hrs, gui.getViewHotel(), gui);
        }
        if(e.getActionCommand().equals("Simulate Booking")){
            this.sim = gui.getSimHotel();
            gui.JButton4ActionPerformed();
            gui.setCreateButtonEnable(false);
            gui.setViewButtonEnable(false);
            gui.setSimButtonEnable(false);
            gui.setRemoveEnable(false);
            gui.setRateEnable(false);
            gui.setChangeEnable(false);
            simController = new SimController(hrs, gui.getSimHotel(), gui);
        }
        if(e.getActionCommand().equals("Remove Hotel")){
            this.rem = gui.getRemHotel();
            gui.JButton3ActionPerformed();
            gui.setCreateButtonEnable(false);
            gui.setViewButtonEnable(false);
            gui.setSimButtonEnable(false);
            gui.setRemoveEnable(false);
            gui.setChangeEnable(false);
            gui.setRateEnable(false);
            remController = new RemoveController(hrs, gui.getRemHotel(), gui);
        }
        if(e.getActionCommand().equals("Change Price")){
            gui.JButton5ActionPerformed();
            this.change = gui.getChangePrice();
            gui.setCreateButtonEnable(false);
            gui.setViewButtonEnable(false);
            gui.setSimButtonEnable(false);
            gui.setRemoveEnable(false);
            gui.setRateEnable(false);
            gui.setChangeEnable(false);
            changeController = new ChangeController(hrs, gui, change);
        }
        if(e.getActionCommand().equals("Change Rate")){
            gui.JButton6ActionPerformed();
            this.rate = gui.getChangeRate();
            gui.setCreateButtonEnable(false);
            gui.setViewButtonEnable(false);
            gui.setSimButtonEnable(false);
            gui.setRemoveEnable(false);
            gui.setRateEnable(false);
            gui.setChangeEnable(false);
            rateController = new RateController(hrs, gui, rate);
        }
    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
    @Override
    public void insertUpdate(DocumentEvent e){

    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
    @Override
    public void removeUpdate(DocumentEvent e){

    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
    @Override
    public void changedUpdate(DocumentEvent e){
        
    }
    
}
