/**
 * <p>Class file for Reservation</p>
 * @author Sean Regindin
 */
public class Reservation {
    /**
     * String
     */
    private String guest_name;
     /**
     * Room
     */
    private Room room;
     /**
     * int
     */
    private int checkIn;
    /**
     * int
     */
    private int checkOut;
    /**
     * double
     */
    private double price;
    /**
     * String
     */
    private String code;

    /**
     * Constructor for the Reservation object
     * @param guest_name name of the guest
     * @param room Room object of the reservation
     * @param checkIn the check in date
     * @param checkOut the check out date
     */
    public Reservation(String guest_name, Room room, int checkIn, int checkOut){
        this.guest_name = guest_name;
        this.room = room;
        this.checkIn = checkIn;
        this.checkOut = checkOut;
        this.price = room.getPrice();
        this.code = "";
    }

    /**
     * Constructor for the Reservation Object
     * @param guest_name the name of the guest
     * @param room Room object of the reservation
     * @param checkIn the check in date
     * @param checkOut the check out date
     * @param code the code that is used
     */
    public Reservation(String guest_name, Room room, int checkIn, int checkOut, String code){
        this.guest_name = guest_name;
        this.room = room;
        this.checkIn = checkIn;
        this.checkOut = checkOut;
        this.price = room.getPrice();
        this.code = code;
    }

    /**
     * Method that gets the guest name
     * @return guest_name
     */
    public String getGuestName(){
        return guest_name;
    }

    /**
     * Method that gets the Room object
     * @return room
     */
    public Room getRoom(){
        return room;
    }

    /**
     * Method that gets the check in date
     * @return checkIn
     */
    public int getCheckIn(){
        return checkIn;
    }

    /**
     * Method that gets the check out date
     * @return checkOut
     */
    public int getCheckOut(){
        return checkOut;
    }

    /**
     * Method that gets the total price of the reservation
     * @return price of the reservation
     */
    public double getTotalPrice(){
        double temp = 0.00;
        //temp += (checkOut - checkIn + 1) * price;
        for(int i = checkIn - 1; i < checkOut; i++){
            temp += (price * room.getDate(i + 1).getPriceRate());
        }

        if(code.equals("PAYDAY")){
            temp -= (checkOut - checkIn + 1) * price * 0.07;
        }
        if(code.equals("I_WORK_HERE")){
            temp -= (checkOut - checkIn + 1) * price * 0.1;
        }
        if(code.equals("STAY4_GET1")){
            temp -= price;
        }
        return temp;
    }

}
