import java.awt.*;
import java.awt.event.ActionListener;
import javax.swing.*;
/**
 * <p>Class file for HRS_UI</p>
 * @author Sean Regindin
 */
public class HRS_UI  extends JFrame{
    /**
     * JButton
     */
    private JButton createButton;
    /**
     * JButton
     */ 
    private JButton removeButton; 
    /**
     * JButton
     */
    private JButton viewButton; 
    /**
     * JButton
     */
    private JButton simButton; 
    /**
     * JButton
     */
    private JButton changeButton; 
    /**
     * JButton
     */
    private JButton rateButton;
    /**
     * JTextArea
     */
    private JTextArea txtHotels;
    /**
     * JLable
     */
    private JLabel lblHotels;
    /**
     * UI_Create
     */
    private UI_Create create;
    /**
     * UI_View
     */
    private UI_View view;
    /**
     * UI_Sim
     */
    private UI_Sim sim;
    /**
     * UI_Remove
     */
    private UI_Remove rem;
    /**
     * UI_Change
     */
    private UI_Change change;
    /**
     * UI_Rate
     */
    private UI_Rate rate;

    /**
     * Constructor for HRS_UI JFrame
     */
    public HRS_UI(){
        super("Trivago");
        setLayout(new BorderLayout());
        setSize(1000, 700);
        
        init();

        setVisible(true);
        setResizable(false);
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
    /**
     * Initializes the JFrame
     */
    private void init(){
            JPanel panelSouth = new JPanel();
            panelSouth.setLayout(new BorderLayout());
            panelSouth.setBackground(Color.lightGray);

            JPanel panelSouthRIGHT = new JPanel();
            panelSouthRIGHT.setLayout(new FlowLayout());
            panelSouthRIGHT.setBackground(Color.lightGray);
            createButton = new JButton("Create Hotel");
            panelSouthRIGHT.add(createButton);

            removeButton = new JButton("Remove Hotel");
            panelSouthRIGHT.add(removeButton);

            viewButton = new JButton("View Hotel");
            panelSouthRIGHT.add(viewButton);
            
            changeButton = new JButton("Change Price");
            panelSouthRIGHT.add(changeButton);

            rateButton = new JButton("Change Rate");
            panelSouthRIGHT.add(rateButton);

            simButton = new JButton("Simulate Booking");
            panelSouthRIGHT.add(simButton);
            panelSouth.add(panelSouthRIGHT, BorderLayout.EAST);
            this.add(panelSouth, BorderLayout.SOUTH);

            JPanel panelNorth = new JPanel();
            panelNorth.setPreferredSize(new Dimension(20, 40));
            panelNorth.setLayout(new BorderLayout());
            panelNorth.setBackground(Color.lightGray);

            JPanel panelNorthLEFT =  new JPanel();
            panelNorthLEFT.setLayout(new FlowLayout());
            panelNorthLEFT.setBackground(Color.lightGray);

            JLabel lblHRS = new JLabel("Hotel Reservation System");
            lblHRS.setForeground(Color.black);
            lblHRS.setFont(new Font("Verdana", Font.BOLD, 20));
            panelNorthLEFT.add(lblHRS);

            JPanel panelNorthRIGHT = new JPanel();
            panelNorthRIGHT.setLayout(new FlowLayout());
            panelNorthRIGHT.setBackground(Color.lightGray);

            lblHotels = new JLabel("Hotels:");
            lblHotels.setForeground(Color.black);
            lblHotels.setFont(new Font("Verdana", Font.PLAIN, 15));
            panelNorthRIGHT.add(lblHotels);

            panelNorth.add(panelNorthRIGHT, BorderLayout.EAST);
            panelNorth.add(panelNorthLEFT, BorderLayout.WEST);

            this.add(panelNorth, BorderLayout.NORTH);

            JPanel panelCENTER = new JPanel();
            panelCENTER.setLayout(new BorderLayout());

            txtHotels = new JTextArea("No Existing Hotels Yet");
            txtHotels.setEditable(false);
            txtHotels.setFocusable(false);
            txtHotels.setFont(new Font("Verdana", Font.PLAIN, 20));
            JScrollPane sp = new JScrollPane(txtHotels);

            panelCENTER.add(sp);

            this.add(panelCENTER, BorderLayout.CENTER);

            JPanel panelWest = new JPanel();
            panelWest.setPreferredSize(new Dimension(30, 100));
            panelWest.setLayout(new FlowLayout());
            panelWest.setBackground(Color.LIGHT_GRAY);
            this.add(panelWest, BorderLayout.WEST);

            JPanel panelEast = new JPanel();
            panelEast.setPreferredSize(new Dimension(30, 100));
            panelEast.setLayout(new FlowLayout());
            panelEast.setBackground(Color.LIGHT_GRAY);
            this.add(panelEast, BorderLayout.EAST);
    }

    /**
     * Method that sets the ActionListener of the buttons
     * @param listener listener of the buttons
     */
    public void setActionListener(ActionListener listener){
        createButton.addActionListener(listener);
        viewButton.addActionListener(listener);
        simButton.addActionListener(listener);
        removeButton.addActionListener(listener);
        changeButton.addActionListener(listener);
        rateButton.addActionListener(listener);
    }

    /**
     * Method that set the text of the lblHotels
     * @param hotelNum number of Hotels
     */
    public void setHotelNumber(int hotelNum){
        lblHotels.setText("Hotels: " + hotelNum);
    }

    /**
     * Method that sets the createButton enabled or not
     * @param enable sets the button enabled if true; else false
     */
    public void setCreateButtonEnable(boolean enable){
        createButton.setEnabled(enable);
    }

    /**
     * Method that sets the viewButton enabled or not
     * @param enable sets the button enabled if true; else false
     */
    public void setViewButtonEnable(boolean enable){
        viewButton.setEnabled(enable);
    }

    /**
     * Method that sets the simButton enabled or not
     * @param enable sets the button enabled if true; else false
     */
    public void setSimButtonEnable(boolean enable){
        simButton.setEnabled(enable);
    }

    /**
     * Method that sets the removeButton enabled or not
     * @param enable sets the button enabled if true; else false
     */
    public void setRemoveEnable(boolean enable){
        removeButton.setEnabled(enable);
    }

    /**
     * Method that sets the changeButton enabled or not
     * @param enable sets the button enabled if true; else false
     */
    public void setChangeEnable(boolean enable){
        changeButton.setEnabled(enable);
    }

    /**
     * Method that sets the rateButton enabled or not
     * @param enable sets the button enabled if true; else false
     */
    public void setRateEnable(boolean enable){
        rateButton.setEnabled(enable);
    }

    /**
     * Method that activates when createButton is pressed
     */
    public void JButton1ActionPerformed(){
        create = new UI_Create();
    }

    /**
     * Method that activates when createButton is pressed
     */
    public void JButton2ActionPerformed(){
        view = new UI_View();
    }

    /**
     * Method that activates when simButton is pressed
     */
    public void JButton4ActionPerformed(){
        sim = new UI_Sim();
    }

    /**
     * Method that activates when removeButton is pressed
     */
    public void JButton3ActionPerformed(){
        rem = new UI_Remove();
    }

    /**
     * Method that activates when changeButton is pressed
     */
    public void JButton5ActionPerformed(){
        change = new UI_Change();
    }

    /**
     * Method that activates when rateButton is pressed
     */
    public void JButton6ActionPerformed(){
        rate = new UI_Rate();
    }

    /**
     * Method that returns the UI_View
     * @return view
     */
    public UI_View getViewHotel(){
        return view;
    }
    
    /**
     * Method that returns the UI_Create
     * @return create
     */
    public UI_Create getCreateHotel(){
        return create;
    }

    /**
     * Method that returns the UI_Sim
     * @return sim
     */
    public UI_Sim getSimHotel(){
        return sim;
    }

    /**
     * Method that returns the UI_Remove
     * @return rem
     */
    public UI_Remove getRemHotel(){
        return rem;
    }

    /**
     * Method that returns the UI_Change
     * @return change
     */
    public UI_Change getChangePrice(){
        return change;
    }

    /**
     * Method that returns the UI_Rate
     * @return rate
     */
    public UI_Rate getChangeRate(){
        return rate;
    }

    /**
     * Method that sets the text of txtHotels
     * @param texts text that will be set
     */
    public void setTxtHotels(String texts){
        txtHotels.setText(texts);
    }

}
