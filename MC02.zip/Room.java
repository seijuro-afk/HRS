/**
 * <p>Class file for Room</p>
 * @author Sean Regindin
 */
public class Room {

    /**
     * String
     */
    private String name;
    /**
     * String
     */
    private String type;
    /**
     * double
     */
    private double price;
    /**
     * Date[]
     */
    private Date[] dates = new Date[31];

    /**
     * Constructor of Room object
     * @param name name of the Room
     */
    public Room(String name){
        this.name = name;
        this.type = "Regular";
        this.price = 1299.00f;
        for(int i = 0; i < 31; i++){
            this.dates[i] = new Date();
        }
    }

    /**
     * Constructor of Room object
     * @param name name of the Room
     * @param price price of the Room
     * @param dates gets the rates of the dates
     */
    public Room(String name, double price, Date[] dates){
        this.name = name;
        this.type = "Regular";
        this.price = price;
        for(int i = 0; i < 31; i++){
            this.dates[i] = new Date(dates[i].getPriceRate());
        }
    }

    /**
     * Method that sets the type of the Room
     * @param type type of the Room that will be changed
     */
    public void setType(String type){
        this.type = type;
    }

    /**
     * Method that sets the name of the Room
     * @param name name of the Room that will be changed
     */
    public void setName(String name){
        this.name = name;
    }

    /**
     * Method that sets the price of the Room
     * @param price price of the Room that will be changed
     */
    public void setPrice(double price){
        this.price = price;
    }

    /**
     * Method that returns the type of the Room
     * @return the type of the room
     */
    public String getType(){
        return type;
    }

    /**
     * Method that returns the name of the Room
     * @return name
     */
    public String getName(){
        return name;
    }

    /**
     * Method that returns the price of the Room
     * @return price
     */
    public double getPrice(){
        return price;
    }

    /**
     * Method that gets a Date object of the Room
     * @param index index of the date that will be returned
     * @return dates[index - 1]
     */
    public Date getDate(int index){
        return dates[index - 1];
    }

    /**
     * Method that returns the Date[] of the Room
     * @return dates
     */
    public Date[] getDates(){
        return dates;
    }

    /**
     * Method that shows if the Room is reserved
     * @return true if reserved; else false
     */
    public boolean isReserved(){
        for(int i = 0; i < 31; i++){
            if(dates[i].getIsBooked() == true)
                return true;
        }
        
        return false;
    }

    /**
     * Method that shows if the Room is reserved at certain dates
     * @param checkIn check in date
     * @param checkOut check out date
     * @return true if it is book; else false
     */
    public boolean isReserved(int checkIn, int checkOut){
        for(int i = checkIn - 1; i < checkOut; i++){
            if(dates[i].getIsBooked() == true){
                return true;
            }
        }
        return false;
    }

    /**
     * Method that shows if the Room is reserved at ceratin Date
     * @param index index of the date
     * @return true if it is reserved; else false
     */
    public boolean isReserved(int index){
        return dates[index - 1].getIsBooked();
    }

    /**
     * Method that sets the reservation details of the Date
     * @param checkIn check in date
     * @param checkOut check out date
     * @param change the change whether the Date is booked
     */
    public void setDatesReservation(int checkIn, int checkOut, boolean change){
        for(int i = checkIn - 1; i < checkOut; i++){
            dates[i].setIsBooked(change);
        }
    }
}
