import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
/**
 * <p>Class file for RateController</p>
 * @author Sean Regindin
 */
public class RateController implements ActionListener, DocumentListener{
    /**
     * UI_Rate
     */
    private UI_Rate rate;
    /**
     * HRS
     */
    private HRS hrs;
    /**
     * HRS_UI
     */
    private HRS_UI gui;

    /**
     * Constructor for RateController Object
     * @param hrs HRS (back-end)
     * @param gui HRS_UI (front-end)
     * @param rate UI_Rate (front-end)
     */
    public RateController(HRS hrs, HRS_UI gui, UI_Rate rate){
        this.hrs = hrs;
        this.gui = gui;
        this.rate = rate;
        rate.setActionListener(this);
    }

    /**
     * Method that updates the view of the gui
     */
    public void updateView(){
        gui.setCreateButtonEnable(true);
        gui.setRemoveEnable(true);
        gui.setViewButtonEnable(true);
        gui.setChangeEnable(true);
        gui.setRateEnable(true);
        gui.setSimButtonEnable(true);
    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e ActionEvent
     */
    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getActionCommand().equals("Ok")){
            if(rate.getHotelNumber() >= 1 && rate.getHotelNumber() <= hrs.getNumHotels()){
                if(hrs.getHotel(rate.getHotelNumber()).hasReservation() == false){
                    if(rate.getDayNumber() >= 1 && rate.getDayNumber() <= 31){
                        if(rate.getRateChange() > 0){
                            hrs.getHotel(rate.getHotelNumber()).setRate(rate.getDayNumber(), rate.getRateChange());
                            updateView();
                            rate.Exit();
                        }
                        else{
                            rate.setTextError("Rate Invalid");
                        }
                    }
                    else{
                        rate.setTextError("Day Invalid");
                    }
                }
                else{
                    rate.setTextError("Hotel has reservation");
                }
            }
            else{
                rate.setTextError("Hotel Invalid");
            }
            
        }
    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
     @Override
    public void insertUpdate(DocumentEvent e){

    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
    @Override
    public void removeUpdate(DocumentEvent e){

    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
    @Override
    public void changedUpdate(DocumentEvent e){
        
    }
}
    

