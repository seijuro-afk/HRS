
import java.awt.Color;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.event.DocumentListener;
/**
 * <p>Class File for UI_Sim</p>
 * @author Sean Regindin
 */
public class UI_Sim extends JFrame{
    /**
     * JLabel
     */
    private JLabel lblGuest;
    /**
     * JLabel
     */
    private JLabel lblHotel;
    /**
     * JLabel
     */
    private JLabel lblRoom;
    /**
     * JLabel
     */
    private JLabel lblCheckIn;
    /**
     * JLabel
     */
    private JLabel lblCheckOut;
    /**
     * JLabel
     */
    private JLabel txtError;
    /**
     * JLabel
     */
    private JLabel lblCode;
    /**
     * JButton
     */
    private JButton conButton;
    /**
     * JTextField
     */
    private JTextField txtGuest;
    /**
     * JTextField
     */
    private JTextField txtHotel;
    /**
     * JTextField
     */
    private JTextField txtRoom;
    /**
     * JTextField
     */
    private JTextField txtCheckIn;
    /**
     * JTextField
     */
    private JTextField txtCheckOut;
    /**
     * JTextField
     */
    private JTextField txtCode;

    /**
     * Constructor for UI_Sim JFrame
     */
    public UI_Sim(){
        super("Simulate Booking");
        setSize(350, 400);
        setLayout(null);

        init();

        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(0);
    }

    /**
     * Method that initializes the JFrame
     */
    private void init(){
        lblGuest = new JLabel("Name: ");
        lblGuest.setBounds(35, 20, 80, 25);
        this.add(lblGuest);

        txtGuest = new JTextField();
        txtGuest.setBounds(100, 20, 165, 25);
        this.add(txtGuest);

        lblHotel = new JLabel("Hotel #: ");
        lblHotel.setBounds(35, 60, 80, 25);
        this.add(lblHotel);

        txtHotel = new JTextField();
        txtHotel.setBounds(100, 60, 30, 25);
        this.add(txtHotel);

        lblRoom = new JLabel("Room #: ");
        lblRoom.setBounds(35, 100, 80, 25);
        this.add(lblRoom);

        txtRoom = new JTextField();
        txtRoom.setBounds(100, 100, 30, 25);
        this.add(txtRoom);

        lblCheckIn = new JLabel("Check In: ");
        lblCheckIn.setBounds(35, 140, 70, 25);
        this.add(lblCheckIn);

        txtCheckIn = new JTextField();
        txtCheckIn.setBounds(100, 140, 30, 25);
        this.add(txtCheckIn);

        lblCheckOut = new JLabel("Check Out: ");
        lblCheckOut.setBounds(35, 180, 70, 25);
        this.add(lblCheckOut);

        txtCheckOut = new JTextField();
        txtCheckOut.setBounds(100, 180, 30, 25);
        this.add(txtCheckOut);

        lblCode = new JLabel("Code: ");
        lblCode.setBounds(35, 220, 80, 25);
        this.add(lblCode);

        txtCode = new JTextField();
        txtCode.setBounds(100, 220, 120, 25);
        this.add(txtCode);

        conButton = new JButton("Confirm");
        conButton.setBounds(175, 260, 80, 25);
        this.add(conButton);

        txtError = new JLabel("");
        txtError.setForeground(Color.red);
        txtError.setBounds(95, 300, 200, 25);
        this.add(txtError);

    }

    /**
     * Method that disposes the JFrame
     */
    public void Exit(){
        this.dispose();
    }

    /**
     * Method that returns the String value of txtGuest
     * @return String(txtGuest)
     */
    public String getGuest(){
        return txtGuest.getText();
    }

    /**
     * Method that returns the String value of txtCode
     * @return String(txtCode)
     */
    public String getCode(){
        return txtCode.getText();
    }

    /**
     * Method that returns the integer value of txtHotel
     * @return int(txtHotel)
     */
    public int getHotel(){
        return Integer.parseInt(txtHotel.getText());
    }

    /**
     * Method that returns the integer value of txtRoom
     * @return int(txtRoom)
     */
    public int getRoom(){
        return Integer.parseInt(txtRoom.getText());
    }

    /**
     * Method that returns the integer value of txtCheckIn
     * @return int(txtCheckIn)
     */
    public int getCheckIn(){
        return Integer.parseInt(txtCheckIn.getText());
    }

    /**
     * Method that return the integer value of txtCheckOut
     * @return int(txtCheckOut)
     */
    public int getCheckOut(){
        return Integer.parseInt(txtCheckOut.getText());
    }

    /**
     * Method that sets the text of txtError
     * @param text the text that will be set onto txtError
     */
    public void setTextError(String text){
        txtError.setText(text);
    }

    /**
     * Method that sets the ActionListener for conButton
     * @param listener listener for the button
     */
    public void setActionListener(ActionListener listener) {
        conButton.addActionListener(listener);
    }

    /**
     * Method that sets the DocumentListener for the JTextField
     * @param listener listener for the text field
     */
    public void setDocumentListener(DocumentListener listener) {
        txtGuest.getDocument().addDocumentListener(listener);
        txtHotel.getDocument().addDocumentListener(listener);
        txtRoom.getDocument().addDocumentListener(listener);
        txtCode.getDocument().addDocumentListener(listener);
    }
}
