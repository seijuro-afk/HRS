import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 * Class file for CancelController
 * @author Sean Regindin
 */
public class CancelController implements ActionListener, DocumentListener{
    /**
     * HRS
     */
    private HRS hrs;
    /**
     * UI_Cancel
     */
    private UI_Cancel cancel;
    /**
     * HotelViewController
     */
    private HotelViewController hwc;
    /**
     * Hotel_View
     */
    private Hotel_View view;
    /**
     * int
     */
    private int hotelIndex;
    /**
     * int
     */
    private int roomIndex;
    /**
     * HRS_UI
     */
    private HRS_UI main;

    /**
     * Constructor of the CancelController
     * @param hrs HRS Object (back-end)
     * @param cancel GUI for Cancel (front-end)
     * @param hwc GUI for HWC (front-end)
     * @param view GUI for Hotel_View (front-end)
     * @param hotelIndex index of the hotel
     * @param roomIndex index of the room
     * @param main GUI for HRS_UI (front-end)
     */
    public CancelController(HRS hrs, UI_Cancel cancel, HotelViewController hwc, Hotel_View view, int hotelIndex, int roomIndex, HRS_UI main){
        this.hrs = hrs;
        this.cancel = cancel;
        this.hwc = hwc;
        this.view = view;
        this.hotelIndex = hotelIndex;
        this.roomIndex = roomIndex;
        cancel.setActionListener(this);
        this.main = main;
    }

    /**
     * Updates the View of the main
     */
    public void updateView(){
        main.setHotelNumber(hrs.getNumHotels());
        main.setTxtHotels(hrs.showHotels());
    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e ActionEvent
     */
    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getActionCommand().equals("Ok")){
            int x = cancel.getResNumber();
            int count = 0;
            for(int i = 0; i < hrs.getHotel(hotelIndex).getReservationNum(); i++){
                if(hrs.getHotel(hotelIndex).getRoom(roomIndex + 1).getName().equals(hrs.getHotel(hotelIndex).getReservation(i + 1).getRoom().getName())){
                    count++;
                }
                if(x == count){
                    hrs.getHotel(hotelIndex).removeReservation(i + 1);
                    count = -999;
                }
            }
            hwc.updateView();
            updateView();
            cancel.Exit();
        }
    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
    @Override
    public void insertUpdate(DocumentEvent e){

    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
    @Override
    public void removeUpdate(DocumentEvent e){

    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
    @Override
    public void changedUpdate(DocumentEvent e){
        
    }
}

