
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 * <p>Class file for RemoveController</p>
 * @author Sean Regindin
 */
public class RemoveController implements ActionListener, DocumentListener{
    /**
     * HRs
     */
    private HRS hrs;
    /**
     * UI_Remove
     */
    private UI_Remove remove;
    /**
     * HRS_UI
     */
    private HRS_UI gui;


    /**
     * Constructor for RemoveController Object
     * @param hrs HRS (back-end)
     * @param remove UI_Remove (front-end)
     * @param gui HRS_UI (front-end)
     */
    public RemoveController(HRS hrs, UI_Remove remove, HRS_UI gui){
        this.hrs = hrs;
        this.remove = remove;
        this.gui = gui;
        remove.setActionListener(this);
    }

    /**
     * Method that updates the view of the gui
     */
    public void updateView(){
        gui.setHotelNumber(hrs.getNumHotels());
        gui.setTxtHotels(hrs.showHotels());
        if(hrs.noHotel()){
            gui.setViewButtonEnable(false);
            gui.setSimButtonEnable(false);
            gui.setRemoveEnable(false);
            gui.setChangeEnable(false);
            gui.setRateEnable(false);
        }else{
            gui.setViewButtonEnable(true);
            gui.setSimButtonEnable(true);
            gui.setRemoveEnable(true);
            gui.setChangeEnable(true);
            gui.setRateEnable(true);
        }
        gui.setCreateButtonEnable(true);
    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e ActionEvent
     */
    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getActionCommand().equals("Ok")){
            if(remove.getHotelNumber() >= 1 && remove.getHotelNumber() <= hrs.getNumHotels()){
                if(hrs.getHotel(remove.getHotelNumber()).hasReservation() == true){
                    remove.setTextError("Error");
                    if(hrs.AllhaveReservation() == true){
                        gui.setCreateButtonEnable(true);
                    }
                }
                else{
                    hrs.removeHotel(remove.getHotelNumber()); 
                    updateView(); 
                    remove.Exit();
                }
            }else{
                remove.setTextError("Error");
            }
        }
    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
    @Override
    public void insertUpdate(DocumentEvent e){

    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
    @Override
    public void removeUpdate(DocumentEvent e){

    }

    /**
     * Method that acts as a bridge for the front-end and the back-end
     * @param e DocumentEvent
     */
    @Override
    public void changedUpdate(DocumentEvent e){
        
    }
}
