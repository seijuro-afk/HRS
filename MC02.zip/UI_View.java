
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.event.DocumentListener;
/**
 * <p>Class file for UI_View</p>
 * @author Sean Regindin
 */
public class UI_View extends JFrame{
    /**
     * JLabel
     */
    private JLabel selRoom;
    /**
     * JLabel
     */
    private JLabel txtError;
    /**
     * JTextField
     */
    private JTextField numHot;
    /**
     * JButton
     */
    private JButton okButton;
    /**
     * Hotel_View
     */
    private Hotel_View view;

    /**
     * Constructor for UI_View JFrame
     */
    public UI_View(){
        super("View Hotel");
        setSize(250, 150);
        setLayout(null);

        init();

        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(0);
    }

    /**
     * Method that initializes the JFrame
     */
    private void init(){
        selRoom = new JLabel("Hotel Number: ");
        selRoom.setBounds(35, 20, 100, 25);
        this.add(selRoom);

        numHot = new JTextField("1");
        numHot.setBounds(130, 20, 50, 25);
        this.add(numHot);

        okButton = new JButton("Ok");
        okButton.setBounds(130, 60, 50, 35);
        this.add(okButton);

        txtError = new JLabel("");
        txtError.setBounds(65, 65, 50, 25);
        this.add(txtError);
    }

    /**
     * Method that returns the integer value of numHot
     * @return int(numHot)
     */
    public int getHotelNumber(){
        return Integer.parseInt(numHot.getText());
    }

    /**
     * Method that sets the text of txtError
     * @param text the text that will be set onto txtError
     */
    public void setTextError(String text){
        txtError.setText(text);
    }

    /**
     * Method that activates when the okButton is pressed
     * @param name name of the Hotel
     */
    public void JButton1ActionPerformed(String name){
        view = new Hotel_View(name);
    }

    /**
     * Method that returns the Hotel_View
     * @return view
     */
    public Hotel_View getHotel_View(){
        return view;
    }
    /**
     * Method that sets the ActionListener of okButton
     * @param listener listener of the button
     */
    public void setActionListener(ActionListener listener) {
        okButton.addActionListener(listener);
    }

    /**
     * Method that sets the DocumentListener of numHot
     * @param listener listener of numHot
     */
    public void setDocumentListener(DocumentListener listener) {
        numHot.getDocument().addDocumentListener(listener);
    }

    /**
     * Method that disposes the JFrame
     */
    public void Exit(){
        this.dispose();
    }

}
